<!DOCTYPE html>
<html>
<head>
	<title>Team Peer Evaluation - Processor</title>

	<style>
		div {
			margin-top: 20px;
			margin-bottom: 20px;
		}
	</style>
	<style>
	.content{
		width:60%;
		margin:0 auto;
		
	}
	.sub_item {
		border: 1px solid #ccc;
		padding: 10px;
	}
	label {
		font-weight: bold;
	}
	table th{
		text-align:left;
	}
</style>
</head>
<body>

<?php
// The code to process recieved data from the form goes to here.
	$team_name = $_POST['team_name'];
	$project_time_start = $_POST['project_date_start'];
	$project_time_end = $_POST['project_date_end'];
	$team_m_name = $_POST['team_m_n'];
	$team_level = $_POST['team_m_l'];
	$team_note = $_POST['team_note'];
	$project_grade = $_POST['project_grade'];
?>
		<div class='content'>
			<div class='item'>
				<h2>Team Project</h2>
			</div>
			<div class='item'>
				<label>Team Name</label>
				<div><?php echo $team_name; ?></div>
			</div>
			<div class='item'>
				<label>Project Time</label>
				<table  style='width:100%'>
					<tr>
						<th>Start</th>
						<th>End</th>
					</tr>
					<tr>
						<td><div><?php echo $project_time_start; ?></div></td>
						<td><div><?php echo $project_time_end; ?></div></td>
					</tr>
				</table>
			</div>
			<div class='item'>
				<label class="col-sm-4 col-form-label">Team Member Details</label>
				<div class='sub_item'>
					<table class='sub_item_team' style='width:100%'>
						<tr>
							<th>Name</th>
							<th>Level</th>
						</tr>
						<?php for($i=0; $i<count($team_m_name); $i++){ ?>
							<tr>
								<td><?php echo $team_m_name[$i]; ?></td>
								<td><?php echo $team_level[$i]; ?></td>
							</tr>
						<?php } ?>
					</table>
				</div>
			</div>
			<div class='item'>
				<label>Project Note</label>
				<div><?php echo $team_note; ?></div>
				</textarea>
			</div>
			<div class='item'>
				<label>Overall Team Grade</label>
				<div><?php echo $project_grade; ?></div>
			</div>
		</div>
</body>
</html>
